<script>
import axios from "axios"
axios.defaults.baseURL = "http://localhost:3000";

import navApp from './components/navApp.vue';
import footerApp from './components/footerApp.vue';

import { RouterView } from 'vue-router';

export default {
  data(){
    return{

    }
  },
  components:{
    navApp,
    footerApp,
    RouterView
  }
}

</script>

<template>
  <nav-app></nav-app>
  <router-view></router-view>
  <!--<footer-app></footer-app> -->
</template>

<style scoped>
*{
  font-family: "Ubuntu";
}
</style>
