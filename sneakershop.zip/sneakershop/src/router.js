import { createRouter, createWebHistory } from 'vue-router';

import mainPage from './views/mainPage.vue';
import pricePage from './views/pricePage.vue';
import shoppingCartPage from './views/shoppingCartPage.vue';
import trackPage from './views/trackPage.vue';

export default createRouter({
    // История переходов сохраняется
    history: createWebHistory(),


    // Роуты и компоненты
    routes: [
        {
            path: '/',
            name:'home',
            component: mainPage
        },
        {
            path: '/cart',
            name:'shoppingCart',
            component: shoppingCartPage
        },
        {
            path: '/price',
            name:'price',
            component: pricePage
        },
        {
            path: '/track',
            name:'track',
            component: trackPage
        }
    ]
})