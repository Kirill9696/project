<script>
    export default{
        data(){
            return{

            }
        },
        methods:{
            goRegistration(){
              this.$router.push({
                    name: 'registration'
              })
            }
        }
    }
</script>

<template>
    <div class="m-5">
        <div class="d-flex justify-content-center">
            <h3>Войдите в аккаунт</h3>
        </div>
        <div class="d-flex justify-content-center">
            <form class="form p-4">
                <div class="mb-3">
                  <label for="exampleInputName1" class="form-label">Имя</label>
                  <input type="text" class="form-control" id="exampleInputName1">
                </div>
                <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">Пароль</label>
                  <input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <button type="submit" class="go">Войти</button>

                <div class="d-flex justify-content-center m-3">
                    <p>Нет аккаунта? <button class="reg" @click="goRegistration">Зарегестрируйтесь</button></p>
                </div>
            </form>
        </div>
    </div>
</template>

<style scoped>
    .form{
        border: solid 1px #D6CCC2;
        border-radius: 10px;
        width: 30%;
    }
    .go{
        padding: 0;
        border: solid 1px #D6CCC2;
        background-color: #D6CCC2;
        border-radius: 10px;
        padding: 10px;
        font-size: 20px;
        font-weight: 400;
        background: none;
        width: 100%;
    }
    .reg{
        background: none;
        border: none;
        font-weight: 600;
        text-decoration: underline;
    }
    @media(max-width: 1350px){
        .form{
            width: 50%;
        }
    }
    @media(max-width: 690px){
        .form{
            width: 90%;
        }
        .go{
            font-size: 13px;
        }
    }
</style>