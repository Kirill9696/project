<script>
    import axios from 'axios';
    axios.defaults.baseURL = "http://localhost:3000";

    export default{
        data(){
            return{
                track:[],
                trackNum: '',
                foundTrack: null
            }
        },
        methods:{
            async loadOrders(){
                let response = await axios.get('/orders');
                this.track = response.data;
            },
            findObjectById() {
                this.foundTrack = this.track.find(obj => obj._id === this.trackNum);
            },
            async removeProduct() {
              await axios.delete('/orders', {
                params: {
                  id: foundTrack._id
                }
              })
              console.log(foundTrack._id)
            }
        },
        mounted(){
            this.loadOrders()
        }
    }
</script>

<template>
    <div class="d-flex justify-content-center mt-4 flex-wrap">
        <div class="tracker col-md-4 m-4 d-inline-block col-11">
                <div class="m-3">
                    <h3>Отследить посылку</h3>
                        <label class="form-label">Трек-номер:</label>
                        <input type="text" class="form-control" v-model="trackNum">
                        <button class="btn btn-secondary mt-3" @click="findObjectById">Найти</button>
                </div>
                <hr>
                <div class="m-3">
                    <h4>Sneakers<span class="pro">.pro</span></h4>
                    <div class="mt-4" v-if="foundTrack">
                        <div>
                            <p>Имя получателя: <span class="info"> {{foundTrack.to}}</span></p>
                        </div>
                        <div>
                            <p>Город получателя: <span class="info"> {{foundTrack.city}}</span></p>
                        </div>
                        <div>
                            <p>Стоимость заказа: <span class="info"> {{foundTrack.total}}</span><span class="info">р</span></p>
                        </div>
                        <div>Заказ: <p>{{ foundTrack.order }}</p></div>
                    </div>
                    <div v-else>
                      <p>Заказа с указанным трек-номером нет</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 m-4 d-inline-block col-11">
                <div class="buyed">
                    <div class="m-3">
                        <h3>Ваши заказы:</h3>
                    </div>
                    <hr>
                    <div class="track m-3" v-for="order in track">
                        <p>{{order._id}}</p>
                        <hr>
                    </div>
                </div>
            </div>
    </div>
</template>

<style scoped>
    .buy{
        padding: 60px 10% 60px 10%;
    }
    .tracker{
        border: solid 1px #D6CCC2;
        border-radius: 10px;
    }
    .buyed{
        border: solid 1px #D6CCC2;
        border-radius: 10px;
    }
    .info{
        font-weight: 500;
    }
    .pro{
        color: #b4b4b4;
    }
    @media (max-width: 1200px){
        .buy{
            padding: 60px 5% 60px 5%;
        }
    }
</style>