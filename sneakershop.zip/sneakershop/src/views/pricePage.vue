<script>
    import axios from 'axios';
    axios.defaults.baseURL = "http://localhost:3000";
    export default{
        data(){
            return{
                sneakers:[],
                title: '',  //может не понадобться
                image: '',  //может не понадобться
                price: '',  //может не понадобться
                brand: '',  //может не понадобться
            }
        },
        methods:{
            async loadSneakers(){
                let response = await axios.get('/sneakers');
                this.sneakers = response.data;
            },
            async editSneakers(item){
                await axios.put('/sneakers', {
                id: item._id
                })
            },
            reloadPage(){
                window.location.reload() //костыль
            }
        },
        mounted() {
            this.loadSneakers()
        }
    }
</script>

<template>
<div class="price">
        <div class="d-flex flex-wrap justify-content-center">
            <div class="sneacker col-md-4 col-lg-3 m-3 d-inline-block p-3" v-for="(item, index) in sneakers">
                <img :src="'public/' + item.image" alt="" width="100%">
                <hr>
                <div class="info">
                        <div>
                            <h4>{{item.title}}</h4>
                        </div>
                        <div>
                            <p>Бренд: {{item.brand}}</p>
                        </div>
                        <div>
                            <p><span class="fw-bold">{{item.price}}</span> ₽</p>
                            <div class="button">
                                <button class="buy" :class="{'buyed': item.inCart}" @click="editSneakers(item), reloadPage()"><span v-if="item.inCart == true">В корзине</span><span v-if="item.inCart == false">В корзину</span></button>
                             </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
    .price{
        padding: 0px 10% 60px 10%;
    }
    .sneacker{
        outline: solid 1px #D6CCC2;
    }
    .buy{
        padding: 0;
        border: solid 1px #D6CCC2;
        background-color: #D6CCC2;
        border-radius: 10px;
        padding: 10px;
        font-size: 20px;
        font-weight: 400;
        background: none;
    }
    .buyed{
        transition: all 1s;
        border: solid 1px #000000;
        background-color: #000000;
        color: white;
    }
    .button{
        margin-top: auto;
    }
    .info{
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 260px;
    }
    @media (max-width: 1200px){
        .price{
            padding: 60px 5% 60px 5%;
        }
    }
    @media (max-width: 767px){
        .info{
            height: 200px;
        }
    }

    @media (max-width: 430px){
        .info{
            height: auto;
        }
    }
</style>