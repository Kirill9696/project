<script>
    import axios from 'axios';
    axios.defaults.baseURL = "http://localhost:3000";

    export default{
        data(){
            return{
                inCart: [],
                sum: 0,
                checked: [],
                username: '',
                city: '',
                status: '',
                titles: '',
                error: false,
                success: false
            }
        },
        methods:{
            async loadBuyedSneakers(){
                let response = await axios.get('/buyed');
                this.inCart = response.data;
            },
            addChecked(cart){
                if (cart.checked) {
                  this.checked.push(cart);
                } else {
                    const index = this.checked.findIndex(item => item.name === cart.name);
                     if (index !== -1) {
                       this.checked.splice(index, 1);
                     }
                }
                this.titles = this.checked.map(checked => checked.title).toString();
            },
            async deleteSneakers(cart){
                await axios.put('/sneakers', {
                id: cart._id
                }),
                cart.inCart = true;
            },
            calculateTotalPrice(cart) {
                 this.sum = this.checked.reduce((total, cart) => total + cart.price, 0);
            },
            reloadPage(){
                window.location.reload()
            },
            async createOrder(cart){
                try {
                  await axios.post('/orders', {
                    username: this.username,
                    city: this.city,
                    sum: this.sum,
                    titles: this.titles
                  });
                
                  // Код ниже будет выполнен только после успешного завершения запроса
                    this.titles = '';
                    this.city = '';
                    this.username = '';
                    this.sum = 0;

                    this.success = true;
                    this.error = false;
                } catch (error) {
                    this.success = false;
                    this.error = true;
                }
            }
        },
        mounted(){
            this.loadBuyedSneakers()
        }
    }
</script>

<template>
    <div class="d-flex justify-content-center flex-wrap">
        <div class="col-md-7">
            <div class="mt-4" v-for="(cart, index) in inCart">
                <div class="cart col-md-11 col-12">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" v-model="cart.checked" @change="addChecked(cart), calculateTotalPrice()">
                        <label class="form-check-label" for="flexCheckChecked">
                          Выбрано
                        </label>
                    </div>
                    
                    <hr>
                    <div class="d-md-flex">
                        <div>
                            <img :src="'public/' + cart.image" alt="" width="100px">
                        </div>
                        <div class="d-flex align-items-center m-md-3">
                            <h4>{{ cart.title }}</h4>
                        </div>
                    </div>
                    <div>
                        <p>Цена: <span class="fw-bold">{{ cart.price }}</span> ₽</p>
                    </div>
                    <form>
                        <div>
                            <button class="btn btn-outline-secondary mt-3" @click="deleteSneakers(cart), reloadPage()" type="submit">Удалить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-3 mt-4 info-cart">
            <div><h4>Оплата</h4></div>
            <div class="mb-3">
                <input type="text" id="disabledTextInput" class="form-control" placeholder="Промокод" disabled>
                <button class="btn btn-primary mt-2 w-100" disabled>Ввести</button>
            </div>
            <div class="mt-5">
                Итого: <span class="fw-bold">{{ sum }}</span> ₽
                <div class="mt-4">
                    <form @submit.prevent="createOrder(cart)">
                              <div class="mb-3">
                                <input type="text" class="form-control" id="exampleInputName" placeholder="Имя получателя" v-model="username">
                              </div>
                              <div class="mb-3">
                                <input type="text" class="form-control" id="exampleInputName" placeholder="Город получателя" v-model="city">
                              </div>
                                <button class="btn btn-secondary mt-2 w-100" type="submit">Заказать</button>
                        </form>
                        <div class="mt-3 d-flex justify-content-center">
                            <div class="alert alert-danger w-100" v-if="error">Произошла ошибка, попробуйте ещё раз</div>
                            <div class="alert alert-primary w-100" v-if="success">Заказ оформлен</div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</template>
<style scoped>
    .cart{
        outline: solid 1px #D6CCC2;
        padding: 40px;
    }
    .info-cart{
        height: 570px;
        outline: solid 1px #D6CCC2;
        padding: 40px;
    }
    @media(max-width:1090px){
        .info-cart{
            height: 640px;
        }
    }
</style>