<script>
    import axios from 'axios';
    axios.defaults.baseURL = "http://localhost:3000";

    export default{
        data(){
            return{
                
            }
        }
    }
</script>

<template>
    <main>
        <div class="d-none d-xl-flex justify-content-center ">
            <img src="../assets/rect.png" alt="" width="80%">
        </div>
        <div class="info">
            <p>Кроссовки — идеальный выбор для активных людей. Они сочетают стиль, комфорт и функциональность, обеспечивая отличную амортизацию, поддержку стопы и долговечность. Большой выбор моделей и дизайнов позволит каждому найти свою идеальную пару.</p>
        </div>
            <div id="carouselExampleSlidesOnly" class="carousel carousel-top slide d-none d-xl-flex" data-bs-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active" data-bs-interval="4000">
                    <img src="../assets/border1.png" class="d-block carousel-image" alt="...">
                  </div>
                  <div class="carousel-item" data-bs-interval="4000">
                    <img src="../assets/border2.png" class="d-block carousel-image" alt="...">
                  </div>
                  <div class="carousel-item" data-bs-interval="4000">
                    <img src="../assets/border3.png" class="d-block carousel-image" alt="...">
                  </div>
                </div>
            </div>
                    <hr>
            <div class="d-flex justify-content-center">
                <div><h2 class="t-bold">Почему мы?</h2></div>
            </div>
            <div class="d-flex justify-content-center flex-wrap gap-4 m-5">
                <div class="d-inline-block rule-block mt-5">
                    <h3>Качественно</h3>
                    <img src="../assets/box-open.png" alt="" height="100px">
                    <div class="d-flex justify-content-center mt-3">
                        <p class="rule">Мы гарантируем вам качественный товар</p>
                    </div>
                </div>
                <div class="d-inline-block rule-block"> 
                    <h3>Безопасно</h3>
                    <img src="../assets/shield-check.png" alt="" height="100px">
                    <div class="d-flex justify-content-center mt-3">
                        <p class="rule">Никаких посредников, только мы, только безопасность</p>
                    </div>
                </div>
                <div class="d-inline-block rule-block mt-5">
                    <h3>Быстро</h3>
                    <img src="../assets/time-fast.png" alt="" height="100px">
                    <div class="d-flex justify-content-center mt-3">
                        <p class="rule">Скорость нашей доставки удивит каждого</p>
                    </div>
                </div>
            </div>
        </main>

</template>

<style scoped>
main{
    margin-top: 80px;
    margin-bottom: 50px;
}
.info{
    width: 23%;
    position: absolute;
    top: 40%;
    left: 20%;
    font-size: 20px;
}
.carousel-top{
    position: absolute;
    top: 7%;
    left: 38%;
}
.carousel-image{
    width: 700px;
}
.rule{
    width: 50%;
}
.rule-block{
    text-align: center;
    width: 320px;
}
.reviews{
    margin-top: 100px;
}
hr{
	margin: 20px auto;
	padding: 0;
	height: 10px;
	border: none;
	border-top: 1px solid #333;
	box-shadow: 0 10px 10px -10px #8c8b8b inset;
    width: 80%;
}
@media (max-width: 1500px){
    .info{
        top: 33%;
    }
}
@media (max-width: 1300px){
    .info{
        top: 26%;
    }
}
@media (max-width: 1199px){
    .info{
        position: relative;
        width: auto;
        top: 0%;
        left: 0%;
        margin: 0px 150px 10px 150px;
    }
    .rule-block{
        margin-top: 0px !important;
    }
}
@media (max-width: 567px){
    .info{
        width: auto;
        margin: 0px 50px 10px 50px;
    }
}
@media (max-width: 1450px){
    .carousel{
        top: -1rem;
        left: 40%;
    }
}
</style>