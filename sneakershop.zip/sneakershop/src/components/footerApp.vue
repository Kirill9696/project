<script>

</script>

<template>
    <footer class="d-flex flex-wrap p-3">
        <div class="m-3">
            <h3>Навигация</h3>
            <a href="" class="navigation">туда сюда</a>
        <br>    
            <a href="" class="navigation">туда сюда</a>
        </div>
        <div class="m-3">
            <h3>Обратная связь</h3>
            <div>
                <a href="" class="m-2"><img src="../assets/discord.png" alt="" height="70px"></a>
                <a href="" class="m-2"><img src="../assets/telegram.png" alt="" height="70px"></a>
                <!-- <a href=""><img src="" alt=""></a> -->
            </div>

        </div>
    </footer>
</template>

<style scoped>
    footer{
        background-color: #000000;
        color: #D6CCC2;
        width: 100%;
    }
    .navigation{
        text-decoration: none;
        color: #8a8787;
    }
</style>