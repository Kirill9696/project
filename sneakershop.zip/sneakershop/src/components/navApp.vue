<script>
  export default{
    data(){
      return{

      }
    },
    methods:{
      goHome(){
        this.$router.push({
              name: 'home'
        })
      },
      goPrice(){
        this.$router.push({
              name: 'price'
        })
      },
      goCart(){
        this.$router.push({
              name: 'shoppingCart'
        })
      },
      goTrack(){
        this.$router.push({
              name: 'track'
        })
      }
    }
  }
</script>

<template>
    <nav class="d-flex justify-content-between p-4 align-items-center flex-wrap navbar">
      <div class="brand top">
        <button class="nav-link" @click="goHome">
      <img src="../assets/logosun.png" alt="Logo" width="50px" class="d-inline-block align-text-top">
      Sneakers<span class="pro">.pro</span>
      </button>
      </div>
      <div class="nav m-3">
      <ul class="me-auto mb-2 mb-lg-0 d-flex flex-wrap">
        <li class="nav-item">
          <button class="nav-link" @click="goHome">Главная</button>
        </li>
        <li class="nav-item">
          <button class="nav-link" @click="goPrice">Каталог</button>
        </li>
        <li class="nav-item">
          <button class="nav-link" @click="goCart">Корзина</button>
        </li>
        <li class="nav-item">
          <button class="nav-link" @click="goTrack">Трекер</button>
        </li>
      </ul>
    </div>
      <div class="r-nav">
      </div>
    </nav>
</template>

<style scoped>
li{
  list-style-type: none;
  
}
ul {
  margin-left: 0;
  padding-left: 0;
}
.switch{
  padding: 0;
  border: none;
  background: none;
}
.pro{
  color: #b4b4b4;
}
.nav-item{
  width: auto;
}
.nav-link{
  color: black;
  font-size: 20px;
  font-weight: 400;
}
.r-nav{
  width: 190px;
  justify-content: end;
}
nav{
  background-color: #f8f8f8;
  margin-bottom: 60px;
}
.login{
  margin-right: 30px;
}
@media(max-width: 882px){
 .r-nav{
  justify-content: start;
 }
}
@media(max-width: 692px){
  .nav-item{
    width: 100%
  }
  .nav-link{
    padding: 10px 0px 10px 0px t;
  }
}
</style>